module.exports = async(client, member) => {

const Discord = require("discord.js");
const firebase = require('firebase');
const database = firebase.database();

let db = await database.ref(`Goodbye/${member.guild.id}`).once('value')

  if(db.val() == null) return;
  let channel = client.channels.cache.get(db.val().canal);

const avatar = member.user.displayAvatarURL({ dynamic: true, size: 1024 })
let embed = new Discord.MessageEmbed()
    .setColor('#7506ff')
    .setThumbnail(member.user.displayAvatarURL({ dynamic: true, format: "png", size: 1024 }))
    .setAuthor(member.user.tag, avatar)
    .setTimestamp()
    .setDescription(`Não foi digno de permanecer no **${member.guild.name}** :wave:`)

    channel.send(`${member.user}`, embed)
}