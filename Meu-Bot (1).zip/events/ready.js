module.exports = async (client) => {

  console.log(`[ ${client.user.username} ] está pronto`);


const Discord = require("discord.js");
client.on("message", message => {
 if(message.content === `<@!766369420423462974>` || message.content === "<@766369420423462974>") {
    let embedmen = new Discord.MessageEmbed()
    .setDescription(`\nMeu prefixo:  \`\`l.\`\` \nPara que eu sirvo?: \`\`Musica e diversão\`\` \nCriador(best): \`\`Peterghosst#0907\`\``)
    .setColor("7506ff")
    .setAuthor(message.author.tag)
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }))
    .setTimestamp()
    .setFooter(client.user.username, client.user.avatarURL())
    message.reply(embedmen)
}
});

};
