const express = require("express");
const app = express();
 
app.listen(() => console.log("💕💕💕💕"));
 
app.use('/ping', (req, res) => {
  res.send(new Date());
});

const fs = require('fs');
const discord = require('discord.js');
const keepAlive = require('./server.js')
const client = new discord.Client({ disableMentions: 'everyone' });
const { CanvasSenpai } = require("canvas-senpai")
const canva = new CanvasSenpai();
const config = require('./config.json');
const firebase = require('firebase');

const { Player } = require('discord-player');

const player = new Player(client);
client.player = player;
client.config = require('./config/bot.json');
client.emotes = require('./config/emojis.json');
client.filters = require('./config/filters.json');
client.commands = new discord.Collection();
client.aliases = new discord.Collection();
client.queue = new Map();


fs.readdir('./events/', (err, files) => {
    if (err) return console.error(err);
    files.forEach(file => {
        const event = require(`./events/${file}`);
        let eventName = file.split(".")[0];
        console.log(`Loading event ${eventName} 🌚`);
        client.on(eventName, event.bind(null, client));
    });
});

fs.readdir('./player-events/', (err, files) => {
    if (err) return console.error(err);
    files.forEach(file => {
        const event = require(`./player-events/${file}`);
        let eventName = file.split(".")[0];
        console.log(`Loading player event ${eventName} 🌚`);
        client.player.on(eventName, event.bind(null, client));
    });
});

const commandFolders = fs.readdirSync('./commands');
for (const folder of commandFolders) {
fs.readdir(`./commands/${folder}`, (err, files) => {
    if (err) return console.error(err);
    files.forEach(file => {
        if (!file.endsWith(".js")) return;
        let props = require(`./commands/${folder}/${file}`);
        let commandName = file.split(".")[0];
        console.log(`Loading command ${commandName} 🌚`);
        client.commands.set(commandName, props);
    });
})
};

client.on("ready", async () => {
  console.log("Pois é a mamasita tá on!!");
   console.log("Estou em " + client.guilds.cache.size + " servidores!\n" + client.user.tag + ", " + client.user.id);
   client.user.setStatus("dnd")
   client.user.setActivity(`${client.guilds.cache.size} servidores!`, {type: "GAMING"})
   
   setInterval( async () => {
       let random = Math.floor(Math.random() * 20);
     
       let totalSeconds = client.uptime / 1000;
  let days = Math.floor(totalSeconds / 86400);
  let hours = Math.floor(totalSeconds / 3600);
  totalSeconds %= 3600;
  let minutes = Math.floor(totalSeconds / 60);
  let seconds = totalSeconds % 60;
     client.user.setStatus("dnd")
     
      if (random == 0) client.user.setActivity(`🐦 | ${client.channels.cache.size} canais!`, {type: "WATCHING"})
      if (random == 1) client.user.setActivity(`😍 | Espalhando alegria e felicidade em ${client.guilds.cache.size} Servidores! :3`, {type: "WATCHING"})
      if (random == 2) client.user.setActivity(`💻 | Utilize ${client.config.prefix}help para obter ajuda`, {type: "LISTENING"})
      if (random == 3) client.user.setActivity(`🐛 | Vc já deu um !d bump nesse server lindo?!`, {type: "PLAYING"})
      if (random == 4) client.user.setActivity(`✨ | Entre no meu servidor de suporte usando ${client.config.prefix}invite`, {type: "WATCHING"})
      if (random == 5) client.user.setActivity("💜 | Anime", {type: "WATCHING"})
      if (random == 6) client.user.setActivity(`🕒 | Online há ${days.toFixed()}d | ${hours.toFixed()}h | ${minutes.toFixed()}m | ${seconds.toFixed()}s`, {type: "LISTENING"})
      if (random == 7) client.user.setActivity(`😍 | Me adicione usando ${client.config.prefix}invite`, {type: "PLAYING"})

     }, 1000 * 5);

});

var configf = {
    apiKey: "AIzaSyAxBH2UF_nl9sHSwInwqP8hERi-8_q0Q18",
    authDomain: "lagartixaroxa-b7423.firebaseapp.com",
    projectId: "lagartixaroxa-b7423",
    storageBucket: "lagartixaroxa-b7423.appspot.com",
    messagingSenderId: "247801661260",
    appId: "1:247801661260:web:a703850e0fdd578cf871e9"
  };
  // Initialize Firebase
  firebase.initializeApp(configf);
  const database = firebase.database();
client.on('message', function(message) {
    if (message.channel.type == "DM") return;
    if (message.author.bot) return;

    database.ref(`Servidores/Levels/${message.guild.id}/${message.author.id}`)
    .once('value').then(async function(db) {
      if (db.val() == null) {
        database.ref(`Servidores/Levels/${message.guild.id}/${message.author.id}`)
        .set({
          xp: 0,
          level: 1
        })
      } else {
        let gerarXP = Math.floor(Math.random() * 5) + 1;

        if (db.val().level*100 <= db.val().xp) {
        database.ref(`Servidores/Levels/${message.guild.id}/${message.author.id}`)
        .update({
          xp: 0,
          level: db.val().level + 1
        });
        message.channel.send(`**Parabéns,** ${message.author}! **você upou para o level** ${db.val().level+1}`)
       } else {
         database.ref(`Servidores/Levels/${message.guild.id}/${message.author.id}`)
         .update({
           xp: db.val().xp + gerarXP
         });
       } 
      }
    })
  });

  client.on('message', function(message) {
    if (message.channel.type == "DM") return;
    if (message.author.bot) return;

    database.ref(`Servidores/Levelsglobal/${message.author.id}`)
    .once('value').then(async function(db) {
      if (db.val() == null) {
        database.ref(`Servidores/Levelsglobal/${message.author.id}`)
        .set({
          xp: 0,
          level: 1
        })
      } else {
        let gerarXP = Math.floor(Math.random() * 5) + 1;

        if (db.val().level*100 <= db.val().xp) {
        database.ref(`Servidores/Levelsglobal/${message.author.id}`)
        .update({
          xp: 0,
          level: db.val().level + 1
        });
        message.channel.send(`**Parabéns,** ${message.author}! **você upou para o level** ${db.val().level+1} **(GLOBAL)**`)
       } else {
         database.ref(`Servidores/Levelsglobal/${message.author.id}`)
         .update({
           xp: db.val().xp + gerarXP
         });
       } 
      }
    })
  });

keepAlive()
client.login(client.config.token_bot);