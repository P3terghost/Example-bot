const Discord = require('discord.js');
const request = require('request'); // request e uma api que você precisa caso vá puxar informações de API em website ou outros conexões externas


module.exports.run = async(bot, message, args, config) => {

      let ip_num = args[0];

      if (!ip_num) { return message.reply('**Por favor, coloque o ip de algum servidor para conferir os status dele!**');}

    
      var api = `https://api.mcsrvstat.us/2/${ip_num}`; // Essa e a api
    message.channel.send("**Buscando informações do servidor...**").then(msg => {

    request(api, function(erro, resposta, info){
      if(erro) return message.channel.send("**Ocorreu um erro na API, notifique ao desenvolvedor ou tente novamente.**");
      info = JSON.parse(info);
      
      let statusDoServidor = ""
      let membrosMax = 0
      let membrosAtual = 0
      let colorEmbed = "FF0000"
      let versao = "Não detectado"
      switch (info.online) {
          case true:
              statusDoServidor = "🟢 Online"
              colorEmbed = "2AFF00"
              membrosMax = info.players.max
              membrosAtual = info.players.online
              versao = info.version 
              break;
        default:
            statusDoServidor = "🔴 Offline"
          break;
      }
      let embed_server = new Discord.MessageEmbed()
      .setTitle("Informações do Servidor.")
      .setColor(colorEmbed)
      .setThumbnail(`https://api.mcsrvstat.us/icon/${ip_num}`)
      .addField("Status:", statusDoServidor)
      .addField("Jogadores:", `${membrosAtual} / ${membrosMax}`)
      .addField("Versão:", versao)
      .setFooter(`Autor: ${message.author.username}`, message.author.avatarURL)
      message.channel.send(embed_server)

    })
    })

}
module.exports.help = {
    name: "status"
}