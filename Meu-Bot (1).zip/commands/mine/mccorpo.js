module.exports = {
  name: 'mcbody',
  aliases: ['mcbody'],
  cooldown: 5,
  guildOnly: false,

  async run(client, message, args) {
    const user = args.join(' ');
    if (!user) return message.channel.send('**Especifique um usuário**');

    const discord = require('discord.js');
    if(user.length > 20) return message.channel.send('Digite no mínimo 20 caractéres')
    const body = `https://mc-heads.net/body/${user}`;

    const embed = new discord.MessageEmbed()
      .setColor('7506ff')
      .setTitle(`Corpo de ${user}`)
      .setImage(body);
    message.channel.send(embed);
  },
};