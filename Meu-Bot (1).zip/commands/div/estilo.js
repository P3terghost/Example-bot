const Discord = require("discord.js")

module.exports.run = async (scott, message, args, prefix) => {

    console.log(`Command stiles ${message.guild.name} ${message.guild.id} ${message.author.tag}`)

    if(message.content.split(' ').slice(1).join(' ').length < 1) return message.channel.send(new Discord.MessageEmbed()
    .setColor("#7506ff")
    .setTimestamp()
    .setDescription(`❌ | ${message.author}, Faça uma pergunta sobre estilo para responder. Exemplo: \` Eu sou descolado?\``))
let replies = ["Sim.","Eu não sei.", "¯\_(ツ)_/¯","Eu só sei que nada sei.","Eu nunca vi (͡ ° ͜ʖ ͡ °)","O importante é o que importa...", "No.", "Realmente não sei sabe?...", "Talvez.","Eu penso que sim.","Não tenho certeza","Provavelmente.","Do meu ponto de vista, sim.","deixa eu pensar...","NÃÃÃÃÃOOOO","Eu não acho."]

let result = Math.floor((Math.random() * replies.length));

let embed = new Discord.MessageEmbed()
.setColor("#7506ff")
.setTimestamp()
.setDescription(`${message.author}, **${replies[result]}**`)
.setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
message.channel.send(embed)
}