const Discord = require("discord.js");

module.exports.run = async (scott, message, args,) => {

    console.log(`Command fagot ${message.guild.name} ${message.guild.id} ${message.author.tag}`)

    if(!args[0]){ message.channel.send(`❌** - ${message.author}, mencione algum membro do servidor**`)

    let volte = args.slice[0]
    if(!volte) return;
    }

    let user1 = message.mentions.users.first() || message.author;
    let gay = Math.round(Math.random() * 100);
    
    let gayembed = new Discord.MessageEmbed()
        .setColor("#7506ff")
        .setDescription(`:rainbow_flag: - Personalidade lgbt do(a) **${user1.tag}** esta em \`${gay}%\`!`);
    return message.channel.send(gayembed);
}; 

exports.help = {
    name: "fagot",
    aliases: ["fagot", "lgbt", "fired"],
    diretorio: "Fun"
  }