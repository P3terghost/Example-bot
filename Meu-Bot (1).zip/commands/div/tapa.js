const Discord = require('discord.js');

exports.run = async (client, message, args) => {
message.delete();
var list = [
  'https://media.tenor.com/images/15605581b37b757016bc0ff441617b54/tenor.gif',
  'https://giphygifs.s3.amazonaws.com/media/11StaZ9Lj74oCY/200.gif',
  'https://64.media.tumblr.com/tumblr_lxr7fo5Xrq1r48fdho1_500.gif'
];

var rand = list[Math.floor(Math.random() * list.length)];
let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('**lembre-se de mencionar um usuário válido para dar o tapa!**');
}
/*
message.channel.send(`${message.author.username} **acaba de beijar** ${user.username}! :heart:`, {files: [rand]});
*/
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setColor('#7506ff')
        .setDescription(`${message.author} acaba de dar um tapa no(a) ${user}`)
        .setImage(rand)
        .setTimestamp()
        .setAuthor(message.author.tag, avatar)
  await message.channel.send(embed);
};