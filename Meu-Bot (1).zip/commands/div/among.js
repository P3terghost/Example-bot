const Discord = require("discord.js")

exports.run = async (client, message, args) => {

let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('**lembre-se de mencionar um usuário!**');}

message.channel.send(`. 　　　。　　　　•　 　ﾟ　　。 　　.
　　　.　　　 　　.　　　　　。　　 。　. 　
.　　 。　　　　　 ඞ 。 . 　　 • 　　　　•
　　ﾟ　　 ${user} era um impostor　 。　.
　　'　　　 2 Impostores Restantes　 　　。
　　ﾟ　　　.　　　. ,　　　　.　 .`);
};