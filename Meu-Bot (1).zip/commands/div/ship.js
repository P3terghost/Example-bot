const Discord = require("discord.js");
const moment = require("moment");


module.exports.run = async(client, message, args) => {

    let user = message.mentions.users.first() || client.users.cache.get(args[0]);

    let target = message.mentions.users.first(2)[1] || this.client.users.cache.get(args[1])
 
    if (!user) {
      return message.reply('**lembre-se de mencionar um usuário válido para dar o tapa!**')};
    if(!target) target = this.client.user;

    function progressBar(progress, maxProgress, size) {
        const progressT = Math.round((size * progress) / maxProgress)
        const progressEmpty = size - progressT;

        const progressText = `█`.repeat(progressT);
        const progressEmptyText = `:`.repeat(progressEmpty)

        return progressText + progressEmptyText;
    }

    let ship = Math.round(Math.random() * 100);
    let max = target.username.length
    let min = max - (max > 5 ? 5 : 3)
    
    let avatar = message.author.displayAvatarURL({ dynamic: true, format: "png", size: 1024 });
    const embed = new Discord.MessageEmbed()
    .setAuthor(message.author.tag, avatar)
    .setTitle(`💜 Ship 💜`)
    .setThumbnail("https://cdn131.picsart.com/322704959025211.png?type=webp&to=min&r=640")
    .setImage('https://thumbs.gfycat.com/VapidUncomfortableAiredale-max-1mb.gif')
    .setColor("#7506ff")
    .setDescription(`\`${user.username}\` + \`${target.username}\` = **${user.username.slice(0, 5)}${target.username.slice(min, max)}**\n\n :sparkling_heart: **Eles tem **\`${ship}%\`** de chance de ficarem juntos.** :sparkling_heart:\n \`${ship}% [ ${progressBar(ship, 100, 50)} ] 100%\``)

  message.channel.send(embed);

};