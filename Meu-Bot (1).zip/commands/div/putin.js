const Discord = require('discord.js');

module.exports = {
  name: 'putin',
  aliases: ['putin', 'walk'],
  cooldown: 3,
  guildOnly: false,

  async run(client, message, args) {
  
    const sayMessage = args.join(' ');
    if (!sayMessage) return message.channel.send('**Por favor, digite algo**');
    const embed = new Discord.MessageEmbed()
      .setDescription(`**${sayMessage}**`)
      .setColor('7506ff')
      .setImage('https://media1.tenor.com/images/20af5cca901f8fe316c93174da43c4e8/tenor.gif')
      .setFooter(`Comando solicitado por ${message.author.tag}`);
    await message.channel.send(embed);

   }
  }
