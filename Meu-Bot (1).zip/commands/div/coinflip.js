const Discord = require("discord.js")

exports.run = async (client, message, args) => {
message.delete();
  var array1 = ["cara", "coroa"];

  var rand = Math.floor(Math.random() * array1.length);

  if (!args[0]) {

  let avatar = message.author.displayAvatarURL({format: 'png'});  
  return message.channel.send(
    new Discord.MessageEmbed()
    .setTitle("Coinflip")
    .setColor("#7506ff")
    .setDescription("\n **Descrição: Voce joga cara ou coroa com o bot!\n \n**Forma de Usa-lo: `coinflip <cara/coroa>`")
    .setFooter(`Autor: ${message.author.username}`, message.author.avatarURL)
    .setTimestamp())
}
else if (args[0].toLowerCase() == array1[rand]) {
    message.channel.send("Deu **" + array1[rand] + "**, você ganhou dessa vez!");
  } 
else if (args[0].toLowerCase() != array1[rand]) {
    message.channel.send("Deu **" + array1[rand] + "**, você perdeu dessa vez!"
    );
  }
};