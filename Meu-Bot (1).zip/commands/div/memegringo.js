const Discord = require("discord.js");
var randomPuppy = require("random-puppy")

exports.run = (scott, message, args) => {

    console.log(`Command meme ${message.guild.name} ${message.guild.id} ${message.author.tag}`)

randomPuppy('memes')
.then(url => {
    var memeEmbed = new Discord.MessageEmbed()
        .setTimestamp()
        .setTitle('Meme Gringo')
        .setFooter(`Autor: ${message.author.username}`, message.author.avatarURL)
        .setTimestamp()
        .setImage(url)
        .setColor('7506ff')
    message.channel.send(memeEmbed);
});
}

exports.help = {
    name: "meme",
    aliases: ["meme"],
    diretorio: "Fun"
  }