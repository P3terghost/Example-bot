const Discord = require('discord.js');

exports.run = async (client, message, args) => {
message.delete();
var list = [
  'https://i.pinimg.com/564x/d6/f4/d4/d6f4d49693307d931bd6161b9054bde4.jpg',
  'https://i.pinimg.com/564x/92/22/5d/92225d9ab88bc9cb1e816cf674172247.jpg',
  'https://i.pinimg.com/564x/dc/da/a5/dcdaa5a805865c1b5c9947ed0854e83e.jpg',
  'https://i.pinimg.com/564x/46/61/ec/4661ec28ed88bcbd98e4a20d4ffa37a1.jpg',
  'https://i.pinimg.com/236x/7d/14/7a/7d147a3a5c7a3f143114193633b09306.jpg',
  'https://i.pinimg.com/564x/b8/6a/f5/b86af559bd394f4d9bfc6b8a010b5c3b.jpg',
  'https://i.pinimg.com/236x/22/9a/8e/229a8e032d2ba25f1d362e0efbae4d81.jpg',
  'https://i.pinimg.com/564x/bb/25/de/bb25deea236556c9d0ad7f484ea9bf22.jpg',
  'https://i.pinimg.com/236x/ea/39/03/ea390308912e8a71058311266c1c41ab.jpg',
  'https://i.pinimg.com/564x/b6/66/10/b66610db4154dd3fc8ea4b774607b1e4.jpg',
  'https://i.pinimg.com/564x/ec/7b/5e/ec7b5e7db408104209f99c19fb9992bc.jpg',
  'https://i.pinimg.com/564x/bf/fe/71/bffe7195ddbf40f7e98b08471f7b6f13.jpg',
  'https://i.pinimg.com/564x/4d/7b/8b/4d7b8bfc83069bd9721ef978f991ee32.jpg',
  'https://i.pinimg.com/564x/2f/58/65/2f5865d3da46e9edc7cbd4dc92040f2a.jpg',
  'https://i.pinimg.com/564x/32/09/8e/32098e20ebb2b03272cc977adcdda24d.jpg',
  'https://i.pinimg.com/564x/3a/1e/06/3a1e06d85c6b25a42358ed2b91de9c7a.jpg',
  'https://i.pinimg.com/564x/86/37/bf/8637bfe028af8300e53b084bdec58206.jpg',
  'https://i.pinimg.com/564x/b9/3e/9d/b93e9d729d9713cdceb0743f6c3beba3.jpg',
  'https://i.pinimg.com/564x/16/08/d3/1608d30455c5402381d464ffe928b28e.jpg',
  'https://i.pinimg.com/564x/fe/b5/3b/feb53b4de42c849d2503d6910e1520de.jpg',
  'https://i.pinimg.com/564x/f4/aa/7b/f4aa7b7befc66c9d45089ee2262c8c6d.jpg',
  'https://i.pinimg.com/564x/0c/a2/31/0ca231ddbd2ce707f4c89f810e29c02f.jpg',
  'https://i.pinimg.com/564x/67/83/d2/6783d2b6cead4e4ba0e81db4b8e2d01e.jpg',
  'https://i.pinimg.com/564x/7d/c2/5f/7dc25f96dc115c7c4622630070fa762e.jpg',
  'https://i.pinimg.com/564x/20/dd/3e/20dd3e21336459444987760bd021f312.jpg',
  'https://i.pinimg.com/564x/cb/5e/44/cb5e446ac40dfd9c419e6d32f59dfd80.jpg',
  'https://i.pinimg.com/564x/a0/f5/76/a0f57603413e3394d5a68b08a0d05069.jpg',
  'https://i.pinimg.com/564x/84/e0/bd/84e0bdea3cc6ab2e94621076c077537b.jpg',
  'https://i.pinimg.com/236x/2f/2b/bc/2f2bbcccf715e7c784932758dee4caa6.jpg',
  'https://i.pinimg.com/564x/1b/e4/09/1be4095f1ca2e509155d0b07ae181f2d.jpg',
  'https://i.pinimg.com/564x/ea/5e/14/ea5e1496afa77c2eb8b659efe5cdf111.jpg',
  'https://i.pinimg.com/236x/fd/bb/41/fdbb4128382982341ad627a2f39b90a2.jpg',
  'https://i.pinimg.com/564x/c5/a7/ae/c5a7ae4108f6490cd828b6070d661296.jpg',
  'https://i.pinimg.com/564x/9e/6f/ec/9e6fec43a2a63a425456b92b2c080a5f.jpg',
  'https://i.pinimg.com/564x/e7/79/15/e77915d073755c635f0ca5a5e5dd170e.jpg',
  'https://i.pinimg.com/564x/9b/d1/d9/9bd1d997bf95f623b158de2678eeee96.jpg',
  'https://i.pinimg.com/564x/37/f8/28/37f828bdf3ce758bc419e6444b09b224.jpg',
  'https://i.pinimg.com/564x/1f/3b/ee/1f3bee95903fe1e08ff7e869003caa78.jpg',
  'https://i.pinimg.com/564x/99/43/4d/99434d955c685dd46f66d7eace16c609.jpg',
  'https://i.pinimg.com/564x/8f/92/5e/8f925e8423ea8b3a455884bedc99411d.jpg',
  'https://i.pinimg.com/564x/b1/97/5a/b1975a2c24350578176197d7568cd364.jpg',
  'https://i.pinimg.com/564x/04/f0/ef/04f0ef6736351b1661de0ff111141575.jpg',
  'https://i.pinimg.com/564x/6c/40/a0/6c40a0d807bdfd77ed9cddf7dae99301.jpg',
  'https://i.pinimg.com/564x/04/f2/23/04f22303031d1e9edb98bbabb784a1a1.jpg',
  'https://i.pinimg.com/564x/80/c3/bc/80c3bc1dc64f3fba843654e854bcd83b.jpg',
  'https://i.pinimg.com/236x/b7/73/52/b773523039bd4189e29ca85d68e491fd.jpg',
  'https://i.pinimg.com/564x/e9/ff/48/e9ff485262ac6d91ed8ce59d7bfcb6a3.jpg',
  'https://i.pinimg.com/236x/64/19/dc/6419dc6018a745b2ad1964965b84a037.jpg',
  'https://i.pinimg.com/564x/a9/53/e8/a953e816c5923f2d20d204cb07ab1aeb.jpg',
  'https://i.pinimg.com/564x/c9/ee/66/c9ee66676c1972f9b4ab52130a6e67a8.jpg',
  'https://i.pinimg.com/564x/09/a9/7e/09a97e3b7a35dbd2aea5ed21ec099c44.jpg',
  'https://i.pinimg.com/564x/29/29/05/2929056fac65aff378a0c4de48e894ab.jpg',
  'https://i.pinimg.com/564x/c3/f1/12/c3f1120ed2446182100ef421a0223078.jpg',
  'https://i.pinimg.com/564x/94/28/50/942850ac4d5eb7f4dbdfd3587b132bd1.jpg',
  'https://i.pinimg.com/564x/73/98/bc/7398bc750ba248f8395d4b5f64e042b1.jpg',
  'https://i.pinimg.com/564x/ed/a3/32/eda3323e27b4fa7e25aaf3d6a28b7e72.jpg',
  'https://i.pinimg.com/564x/a9/aa/04/a9aa04805ab69e4dcbacd44521d894cd.jpg',
  'https://i.pinimg.com/564x/96/39/b2/9639b2c197414cdc4f96d946ddb6f71a.jpg',
  'https://i.pinimg.com/564x/1a/b0/9b/1ab09b6be7fddc916eb66a1d406b4fa0.jpg',
  'https://i.pinimg.com/564x/94/22/87/94228776b74f7beefa202603a8487097.jpg',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRFyeJiES8ImKoDvjsJFBtU-MIlSJDjB8eCpw&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQS9F_Qairy7KdA8V7vDcf8ooq8pwNMKSY98Q&usqp=CAU',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSpgdt9FcfbWf9IpgUh4eI02bLi-Q3J-FZrTw&usqp=CAU',
  'https://images3.memedroid.com/images/UPLOADED132/5e06186b94d36.jpeg',
  'https://images3.memedroid.com/images/UPLOADED490/5e1f333dc8b38.jpeg',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcS9HzEQEhfHnX9QvIo8PY4DCR02fjmV3vbD2Q&usqp=CAU',
  'https://pbs.twimg.com/profile_images/875464015337730048/Cta3L18Q_400x400.jpg',
  'https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcStLhrIIxnnrBP057rk5mDh7vxxq8gvxCBKAQ&usqp=CAU',
  'https://img.estadao.com.br/thumbs/640/resources/jpg/6/4/1578055675846.jpg?xcd_image_optimization=false',
  'https://www.osaogoncalo.com.br/img/inline/70000/meme7_00076957_5.jpg?xid=191742',
  'https://i.pinimg.com/originals/d8/34/52/d834525869d6d3e22bd10d1fbe9aee2a.jpg',
  'https://i.pinimg.com/originals/0e/fb/bf/0efbbf47e3fea33da2057cd1a1d1e7ff.jpg',
  'https://preview.redd.it/8dhx4odt51d51.jpg?auto=webp&s=12341938f5ef0915e82408589e3efd0fec672963',
  'https://i.pinimg.com/236x/42/f0/f3/42f0f36c57c57648b77f9160953f1797.jpg',
  'https://i.redd.it/gbewe6zymof51.png',
  'https://images3.memedroid.com/images/UPLOADED211/5f33b3ca9372d.jpeg'
];

var rand = list[Math.floor(Math.random() * list.length)];
  const embed = new Discord.MessageEmbed()
        .setTitle('Meme images')
        .setColor('#7506ff')
        .setImage(rand)
        .setTimestamp()
        .setThumbnail()
        .setFooter(`Autor: ${message.author.username}`, message.author.avatarURL)
  await message.channel.send(embed);
};