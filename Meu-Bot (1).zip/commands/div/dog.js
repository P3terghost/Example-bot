const gifSearch = require('gif-search')

exports.run = (scott, message, args) => {
  gifSearch.random('dog').then(
    gifUrl => message.channel.send({
        embed: {
            color: '#7506ff',
            title: `Gifs de Cachorro`,
            timestamp: new Date(),
            image: {url: gifUrl},
        },
    })
  )
}

exports.help = {
  name: "dog",
  aliases: ["dog"],
  diretorio: "Fun"
}