const Discord = require('discord.js');
const Tenor = require("tenorjs").client({
    "Key": "tenor api key", // https://tenor.com/developer/keyregistration
    "Filter": "off", // "off", "low", "medium", "high", not case sensitive
    "Locale": "pt_BR", // Your locale here, case-sensitivity depends on input
    "MediaFilter": "minimal", // either minimal or basic, not case sensitive
    "DateFormat": "D/MM/YYYY - H:mm:ss A" // Change this accordingly
});
const { MessageEmbed, MessageAttachment } = require("discord.js");


exports.run = async (client, message, args) => {

  const sayMessage = args.join(' ');

  if (!sayMessage) {
    return message.channel.send('**⭕ | Lembre-se de colocar o tema do gif(Não sou muito precisa 😓)**')
  }

     
Tenor.Search.Random(`${sayMessage}`, "1").then(Results => {
  
    if (Results[0] == null) return message.channel.send(`Não encontrei nenhum gif sobre \`${args.join(" ")}\`.`);

      Results.forEach(Post => {

             console.log(`Item ${Post.id} (Created: ${Post.created}) @ ${Post.url}`);

            message.channel.send('**aqui esta o gif desejado, ou não**')
            message.channel.send(Post.url)
      });
     })
     
}