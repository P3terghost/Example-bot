module.exports = {
  name: 'cancel',
  aliases: ['cancel', 'cancelar'],
  cooldown: 2,
  guildOnly: true,
  async run(client, message, args) {
    const list = [
      'ser velho(a)',
      'ser feio(a)',
      'fazer nada',
      'comer as batatinhas',
      'criticar a Ao-chan',
      'falar que anime é ruim',
      'não gostar de bebê',
      'gostar mais de dog dq cat',
      'ter ignorado ele',
      'dar um fora nele',
      'ser irritante',
      'ser arrgoante',
      'ser chato(a)',
      'ser um gnomio',
      'ser nuttela',
      'gostar do Fel*pe Net*',
      'ser egoista',
      'não ter dividido o lanche',
      'não ter passado a seha da netflix >:(',
    ];

    const rand = list[Math.floor(Math.random() * list.length)];
    const user = message.mentions.users.first() || client.users.cache.get(args[0]);
    if (!user) {
      return message.channel.send('lembre-se de mencionar um usuário válido para cancelar!');
    }
    await message.channel.send(`${message.author} cancelou ${user} por ${rand}`);
  },

};