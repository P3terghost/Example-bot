const Discord = require("discord.js");
const { get } = require("superagent");
module.exports.run = async(client, message, args) => {

    try {
        if(!args[0]){
message.reply('⛔ **Você precisa colocar o que vai ser falado na imagem!')
return;
}
        let url = `https://nekobot.xyz/api/imagegen?type=changemymind&text=${args.join(" ")}`
        get(url).then(res => {
            const embed = new Discord.MessageEmbed()
            .setAuthor("Mude minha opnião..")
            .setImage(res.body.message)
            setTimeout(() => {
                return message.channel.send(embed);
            }, 200);
        });
    } catch(err) {
        console.log(err)    
    }
};