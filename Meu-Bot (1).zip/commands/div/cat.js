const gifSearch = require('gif-search')

exports.run = (scott, message, args) => {
  gifSearch.random('cat').then(
    gifUrl => message.channel.send({
        embed: {
            color: '#7506ff',
            title: `Gifs de Gato`,
            timestamp: new Date(),
            image: {url: gifUrl},
        },
    })
  )
}

exports.help = {
  name: "cat",
  aliases: ["cat"],
  diretorio: "Fun"
}