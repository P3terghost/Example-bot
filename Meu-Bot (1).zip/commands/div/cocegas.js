const { MessageEmbed } = require('discord.js'),
superagent = require("superagent");

//protótipo de um comando de ação, diversão e/ou roleplay
module.exports = {

    name: "tickle",
    aliases: ["cócegas", "cocegas"],

    run: async (client, message, args) => {
      message.delete();
      
      //verifica se o usuário não digitou nada
      if(!args[0]) return message.reply(`mencione um usuário!`);

      //você pode mencionar, inserir o id, nome, tag ou o apelido do usuário (para executar o comando)
      let member = message.guild.members.cache.get(args[0].replace("<@", "").replace("!", "").replace(">", "")) ||
      message.guild.members.cache.find(m => m.user.username === args.join(" ")) ||
      message.guild.members.cache.find(m => m.user.tag === args.join(" ")) ||
      message.guild.members.cache.find(m => m.nickname === args.join(" "));

      //através disto você poderá gerar gifs aleatórios
      const { body } = await superagent.get("https://nekos.life/api/v2/img/tickle");
      //caso queira que gere outros gifs aleatórios acesse: https://github.com/Nekos-life/nekos-dot-life/blob/master/typings/index.d.ts

      //caso o usuário especificado não seja válido
      if(!member) return message.reply(`mencione um usuário válido!`);

      let avatar = message.author.displayAvatarURL({format: 'png'});
      const embed = new MessageEmbed()
      .setColor("#7506ff")
      .setImage(body.url)
      .setAuthor(message.author.tag, avatar)
      .setDescription(`${message.author} fez cócegas em ${member}!`);
      message.reply(embed);
  }
}