const gifSearch = require('gif-search')

exports.run = (scott, message, args) => {
  gifSearch.random('waifu').then(
    gifUrl => message.channel.send({
        embed: {
            color: '#7506ff',
            title: `Gifs de Animes`,
            timestamp: new Date(),
            image: {url: gifUrl},
        },
    })
  )
}

exports.help = {
  name: "gifanime",
  aliases: ["gifanime"],
  diretorio: "Fun"
}