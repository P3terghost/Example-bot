const Discord = require('discord.js');

exports.run = async (client, message, args) => {
message.delete();
var list = [
  'O que um matemático disse para um índio? 8 pi',
  'Papai noel fez tatuagem.. ..mas é de rena',
  'Porque a plantinha não vai no médico de domingo?\n Porque só tem médico de plantão',
  'O cara era treinador de ursos e aposentou. Qual o nome do filme?\n O ex ursista.',
  'Duas baleias entraram num bar, Começaram a discutir e se mataram com pistolas.\n No outro dia o jornal noticia a calamidade: Baleia baleia baleia',
  'Qual a diferença entre ignorância e apatia?\n Eu não sei e eu não me importo',
  'Quanto vale um terapeuta?\n 1024 gigapeutas',
  'O que os ditadores da URSS faziam no telefone?\n Passavam Trotsky',
  'Sabe por que a formiga só tem quatro amigas?\n Por que se tivessem cinco, seria uma fivemiga',
  'O Draco Malfoy\n e já voltou.',
  'Porque o Mário pequeno é melhor nas fases aquáticas?\n Porque ele é o marinho',
  'Já imaginou se chovesse macarrão?\n Ia ser massa demais.',
  'Mas isto dai é maionese ou é junhonese?',
  'Qual loja de roupas se come no natal?\n A C&A de Natal.',
  'Era uma vez um pintinho que não ria...\n Joguei ele na parede e ele rachou o bico.',
  'Por que instalaram escadas no oculista?\n Para óculos de-graus',
  'Hoje morreu o inventor do corretor automático.\n Que descafeinado em paz.',
  'Por que o besouro fez tratamento para rejuvenescimento?\n Ele queria se tornar um ex-cara-velho.',
  'Sabe o que acontece quando uma galinha morre?\n Ela vira uma alma penada',
  'Quantas crianças cabem em uma circunferência?\n 2(pi)raio',
  'Por que o professor de Lingua Portuguesa não para nos semáforos quando conduz o próprio carro?\n Porque ele considera "dirigir" um verbo transitivo direto.',
  'Qual o contrário de volátil?\n Vem cá sobrinho.',
  'Reduza a queda de cabelo em 50%...\n Tome banho sentado.',
  'Por que o vidente se mudou para Berlim?\n Para aprender a-lê-mão',
  'Bom mesmo é o site do cavalo:\n www.cavalo.com.com.com.com.com.com',
  'Qual o prato preferido dos maconheiros?\n Bife aserbolado',
  'Qual o médico que é bem desligado?\n o OFFtalmologista',
  'Qual é o estado americano que só tem tempestade?\n ... Ohio',
  'O que o Ash falou quando o Pikachu ganhou dele no Poquer\n Pô, que mão',
  'Sabe porque Napoleão era chamado pra todas as festas?\n Porque ele era bom na party',
  'Papai Noel fica doente ao saber que falta uma rena e não pode entregar os presentes...\n ... ele ficou com insuficiência renal.',
  'Qual o nome da régua feita de Oxigênio?\n Arquimedes',
  'O gaúcho não achava o carro no estacionamento. Qual é o modelo do carro?\n Kadetchê.',
  'Qual o estilo musical preferido das plantas?\n Reggae.',
  'Por que o programador tomou paracetamol?\n Porque estava COMPUTADOR de cabeça.',
  'O que o saci disse para a sacia?\n Fica de 3.',
  'Sempre que minha sobrinha assiste comercial de remédio na TV ela ri\n Será pq o ministério da saúde adverte?',
  'Qual o antivírus que os flintstones usam?\n YabadaBAIDU',
  'Vocês ouviram falar dos dois bandidos que roubaram um calendário?\n ...parece que pegaram seis meses cada um!',
  'Uma orquestra foi atingida por um raio. Só o maestro sobreviveu.\n Ele foi despedido por ser um mau condutor.',
  'O que a mãe açaí disse para seus filhos?\n O último açaí fecha a porta',
  'Eu acordo mais tarde\n O Edir Macedo',
  'Como se chama uma pessoa que pinta carros?\n Car-pinteiro',
  'Acho que eu deveria fazer um curso de chaveiro\n É um curso que abre portas',
  'Uma cobra estava em divida com outra cobra....\n No jornal: Cobra cobra cobra',
  'Cheguei em uma estrela e perguntei "pq vc não mia?" E ela respondeu que astronomia',
  'Como faz para queimar 1500 calorias em 30 minutos?\n Deixa a pizza no forno alto',
  'Um anão foi no centro espirita e estava muito triste...\n e quando ele saiu de la ele estava muito feliz. E peguntaram: Por que você esta feliz? Então ele disse: E porque descobrir que não sou mais anão sou medium.',
  'Mês passado, comecei a aprender alemão com meu tio...\n ... acredita que agora já consigo até prever o futuro das pessoas?',
  'Manuel registrando o filho no cartório...\n Qual o nome do bebê? -- Ora pois, será Arquibancada do Vasco. -- O que? Esse nome eu não posso colocar! -- E porque não? O meu amigo Joaquim conseguiu dar o nome do filho dele de Geraldo Santos!',
  'se no Brasil, os filmes são baseados em fatos reais\n então nos EUA são baseados em fatos dólares?',
  'Eu não sabia que meu pai tinha um segundo emprego como professor...\n Mas um dia, quando cheguei em casa, todas as provas estavam lá.',
  ' Se o cachorro tivesse religião, qual seria?\n Cão-domblé',
  'por quê a velhinha nao usa relogio?\n porque ela é um sen hora',
  'Cheguei pro meu amigo na joalheria onde ele trabalha.\n Eu perguntei: "E aí, tudo jóia?".',
  'Por que o louco, quando joga futebol, só consegue marcar gol com os pés?\n Por que ele não bate bem de cabeça.',
  'O que o ascensorista disse pro Batman no elevador?\n Vai DC?',
  'Por que a cobra resolveu virar uma escova de cabelo?\n Porque ela estava cansada de serpente. ENTENDEU? ENTENDEU? SERPENTE -- SER PENTE',
  'O que um pinheiro contou para o outro? Uma pinhada',
  'Por que o pinheiro não se perde?\n Porque ele tem umapinha'
];

var rand = list[Math.floor(Math.random() * list.length)];
let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Piadas de tiozão')
        .setColor('#7506ff')
        .setDescription(rand)
        .setTimestamp()
        .setThumbnail()
        .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}));
  await message.channel.send(embed);
};