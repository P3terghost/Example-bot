const Discord = require('discord.js');

module.exports.run = async (client, message, args, prefix) => {

    
    const avatar = client.user.displayAvatarURL({ dynamic: true, size: 2048 })
    
    const embed = new Discord.MessageEmbed()
      .setAuthor(`${client.user.name}`, avatar)
      .setDescription(` **__[Clique Aqui](${avatar})__** para Baixar o Avatar`)
      .setImage(avatar)
      .setColor("#7506ff")
      .setFooter(`Comando Executado por ${message.author.tag}` , message.author.displayAvatarURL({ dynamic: true, size: 2048 }))
    message.channel.send(embed)
    }