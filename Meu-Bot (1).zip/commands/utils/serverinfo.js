const Discord = require('discord.js');
const moment = require("moment");

exports.run = async (client, message, args) => {
message.delete();

console.log(`comando serverinfo ${message.guild.name} ${message.guild.id} ${message.author.tag}`)


    let online = message.guild.members.cache.filter(member => member.user.presence.status !== 'offline');
    let day = message.guild.createdAt.getDate()
    let month = 1 + message.guild.createdAt.getMonth()
    let year = message.guild.createdAt.getFullYear()
    let sicon = message.guild.iconURL
    
    if (month<10) {
        month = "0"+month;
    }


let region = message.guild.region
       
let = region;
if(region === "brazil") region = ":flag_br: Brazil";
if(region === "eu-central") region = ":flag_eu: Central Europe";
if(region === "hongkong") region = ":flag_hk: Hong Kong";
if(region === "japan") region = ":flag_jp: Japan";
if(region === "russia") region = ":flag_ru: Russia"
if(region === "singapore") region = ":flag_sg: Singapure";
if(region === "southafrica") region = ":flag_za: South Africa";
if(region === "sydney") region = ":flag_au: Sydney";
if(region === "us-central") region = ":flag_us: Us Central";
if(region === "us-east") region = ":flag_us: Us East";
if(region === "us-south") region = ":flag_us: South South";
if(region === "us-west") region = ":flag_us: Us West";
if(region === "eu-west") region = ":flag_eu: Western Europe";



let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle(`Informações do servidor ${message.guild.name}`)
        .setAuthor(`INFO: ${message.guild.name}`)
        .setColor('#7506ff')
        .addFields(
            { name: ':computer: Nome:', value: `${message.guild.name}`, inline: true },
            { name: ':computer: ID:', value: `${message.guild.id}`, inline: true },
            { name: ':earth_americas: Região:', value: `${region}`, inline: true },
        )
        .addFields(
            { name: ':crown: Dono:', value: `${message.guild.owner.user.tag}`, inline: true },
            { name: ':calendar_spiral: Data de Criação', value: `${day}/${month}/${year}`, inline: true },
        )
        .addFields(
            { name: ':star2: Data da minha entrada:', value: `${moment(message.guild.member(client.user.id).joinedAt).format("L")} ${moment(message.guild.member(client.user.id).joinedAt).startOf("day").fromNow()}`, inline: true },
        )
        .addFields(
            { name: ':grinning: Emojis:', value: `${message.guild.emojis.cache.size}`, inline: true },
        )
        .addFields(
            { name: ':speech_balloon: Canais:', value: `${message.guild.channels.cache.size}`, inline: true },
            { name: `:busts_in_silhouette: Membros: ${message.guild.memberCount}`, value: `**:green_circle: Online: ${online.size}**`, inline: true },
            { name: ':passport_control: Cargos do Servidor:', value: `${message.guild.roles.cache.size}`, inline: true },
            { name: ':globe_with_meridians: Bots:', value: `${message.guild.members.cache.filter(m => m.user.bot).size}`, inline: true},
            { name: `:purple_heart: Boost: ${message.guild.premiumSubscriptionCount}`, value: `**Boost(s) Level Server:** ${message.guild.premiumTier}`, inline: true },
        )
        .setImage('https://64.media.tumblr.com/a730d99062625d092faaac1efc558bf4/tumblr_ppki9k9suj1vgzd4so1_r1_500.gif')
        .setTimestamp()
        .setThumbnail(message.guild.iconURL({format:'jpeg', size:1024}))
        .setFooter(`Autor: ${message.author.username}`, message.author.avatarURL)
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
};