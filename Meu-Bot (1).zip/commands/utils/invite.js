const Discord = require('discord.js');

module.exports = {
  name: 'invite',
  aliases: ['invite', 'add', 'convidar', 'addbot'],
  cooldown: 3,
  guildOnly: false,
  async run(client, message, args) {
    const embed = new Discord.MessageEmbed()
      .setColor('#7506ff')
      .setTitle('INVITE')
      .setDescription('Gostou de mim e quer me adiocionar em outro servidor? \n Então vou deixar aqui em baixo os liks para me adicionar e o do meu servidor ^-^')
      .addField('Euzinha:', ' **[clique aqui](https://discord.com/oauth2/authorize?client_id=766369420423462974&scope=bot&permissions=8206) **', true)
      .addField('Meu servidor bunitu :3', '**[clicando aqui](https://discord.gg/7g7FPN22rF) **', true)
      .setImage('https://i.ppy.sh/369ce4f3ca9d6491d472413dd241c7c13cc7269b/68747470733a2f2f36342e6d656469612e74756d626c722e636f6d2f30616437396361366561333734343636633131666239633139343333376564362f666265343063666439623264376530372d34302f73343030783630302f623334623932353233613537373463326632613533343935323132393237356430646261313362612e67696676')
      .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }))
      .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({ format: 'png' }));
    await message.channel.send(embed);
  },

};