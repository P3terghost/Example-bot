const Discord = require("discord.js"); 

exports.run = async (client, message) => {
message.delete();

  const embed1 = new Discord.MessageEmbed()
    .setColor('7506ff')
    .setAuthor('Help / Ajuda')
    .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
    .addField('Comandos de Música', 'Reaja com 📗 para obter ajuda sobre os comandos de **Música**.',)
    .addField('Comandos de Administração', 'Reaja com 📕 para obter ajuda sobre os comandos de **Administração**.')
    .addField('Comandos de Diversão', 'Reaja com 📙 para obter ajuda sobre os comandos de **Diversão**.')
    .addField('Comandos Diversos', 'Reaja com 📘 para obter ajuda sobre comandos **diversos**.')
    .setDescription('**Ola! Precisa de ajuda? Sou um simples bot de diversão e musica! Aqui a baixo estará alguns comandos basicos meu!**')
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }));

    const embed2 = new Discord.MessageEmbed()
    .setColor('7506ff')
    .setAuthor('COMANDOS DE MÚSICA')
    .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
    .addField('play ou tocar', '\`\`Usado para tocar alguma musica no canal de voz!\`\`', true)
    .addField('stop ou pause', '\`\`Usado para parar a múscia!\`\`', true)
    .addField('skip', '\`\`Usado para pular a música atual!\`\`', true)
    .addField('resume', '\`\`Usado para voltar a tocar a música após o pause!\`\`', true)
    .addField('lista', '\`\`Usado para ver a lista de música!\`\`', true) 
    .addField('rlista', '\`\`Apaga a lista atual de músicas!\`\`', true)
    .addField('aleatorio', '\`\`Usado para tocar as músicas aleatoriamente!\`\`', true)
    .addField('np', '\`\`Mostra as informações da música atual!\`\`', true)
    .addField('loop', '\`\`Deixara sua música tocando em loop!\`\`', true)
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }));

    const embed3 = new Discord.MessageEmbed()
    .setColor('7506ff')
    .setAuthor('COMANDOS DE ADMINISTRAÇÃO')
    .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
    .addField('ban', '\`\`Da ban no usuario mencionado!\`\`', true)
    .addField('kick', '\`\`Da Kick o usuario mencionado!\`\`', true)
    .addField('mute', '\`\`Muta o usuario menionado!\`\`', true)
    .addField('anuncio', '\`\`Usado para anunciar algo(embed)!\`\`', true)
    .addField('sayembed', '\`\`Usado para o bot falar algo em embed!\`\`', true)
    .addField('say', '\`\`Usado para o bot falar algo!\`\`', true)
    .addField('clear', '\`\`Apague entre 0 a 99 mensagens!\`\`', true) 
    .addField('votação', '\`\`Usado para anunciar uma votação(embed)!\`\`', true)
    .addField('bomba', '\`\`Usado para destruir um chat!\`\`', true)
    .addField('setwelcome', '\`\`Defina o canal de boas vindas\`\`', true)
    .addField('setgoodbye', '\`\`Defina o canal de saida\`\`', true)
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }));

    const embed4 = new Discord.MessageEmbed()
    .setColor('7506ff')
    .setAuthor('COMANDOS DE DIVERSÃO')
    .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
    .addField('meme', '\`\`Mostra alguns memes ruins..kkk\`\`', true)
    .addField('memegringo', '\`\`Mostra mais memes ruins...kkk!\`\`', true)
    .addField('piada', '\`\`Eu conto uma piada!\`\`', true)
    .addField('ship', '\`\`Shippe seus amigos (͡ ° ͜ʖ ͡ °)\`\`', true)
    .addField('conquista', '\`\`Obtenha uma conquista!\`\`', true)
    .addField('among', '\`\`2 Impostores restantes??\`\`', true)
    .addField('lgbt', '\`\`Veja qual o seu nivel tchola no momento!\`\`', true)
    .addField('cmm', '\`\`Mude minha opinião!\`\`', true)
    .addField('beijar', '\`\`Beije alguem!\`\`', true)
    .addField('tapa', '\`\`De um tapa em alguem!\`\`', true) 
    .addField('abraço', '\`\`abraçe alguem!\`\`', true)
    .addField('cocegas', '\`\`faça cocegas em alguem! (͡ ° ͜ʖ ͡ °)\`\`', true)
    .addField('coinflip', '\`\`Jogue um cara ou coroa comigo!\`\`', true)
    .addField('8ball', '\`\`Me faça um pergunta de sim/não\`\`', true)
    .addField('cat', '\`\`Muitos Gatinhos! :3\`\`', true)
    .addField('dog', '\`\`Muitos doguinhos! :3\`\`', true)
    .addField('gifanime', '\`\`Gifs de animes\`\`', true)
    .addField('searchgif', '\`\`Procure algum gif\`\`', true)
    .addField('estilo', '\`\`Eu sou descolada?\`\`', true)
    .addField('rank', '\`\`Veja o toprank\`\`', true)
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }));

    const embed5 = new Discord.MessageEmbed()
    .setColor('7506ff')
    .setAuthor('COMANDOS DIVERSOS')
    .setFooter(`• Autor: ${message.author.tag}`, message.author.displayAvatarURL({format: "png"}))
    .addField('invite', '\`\`Meu convite ^-^!\`\`', true)
    .addField('uptime', '\`\`A quanto tempo on após meu upload!\`\`', true)
    .addField('info', '\`\`Informações sobre mim (͡ ° ͜ʖ ͡ °)!\`\`', true)
    .addField('avatar', '\`\`Mando a foto do usuario!\`\`', true)
    .addField('serverinfo', '\`\`Mostro informações do servidor(desenvolvimento)!\`\`', true)
    .addField('servericon', '\`\`Eu mando a foto do servidor!\`\`', true)
    .addField('privado', '\`\`Crie um canal privado para vc e seu amigo (͡ ° ͜ʖ ͡ °)!\`\`', true) 
    .addField('emoji', '\`\`Mando um amoji(até animado)!\`\`', true)
    .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }));

  message.channel.send(embed1).then(msg=> {
msg.react("📗").then(r => {
msg.react("📕")
msg.react("📙")
msg.react("📘")

const music = (reaction, user) => reaction.emoji.name === '📗' && user.id === message.author.id;
const adm = (reaction, user) => reaction.emoji.name === '📕' && user.id === message.author.id;
const div = (reaction, user) => reaction.emoji.name === '📙' && user.id === message.author.id;
const info = (reaction, user) => reaction.emoji.name === '📘' && user.id === message.author.id;
const musicl = msg.createReactionCollector(music, { time: 60000 });
const adml = msg.createReactionCollector(adm, { time: 60000 });
const divl = msg.createReactionCollector(div, { time: 60000 });
const infol = msg.createReactionCollector(info, { time: 60000 });


musicl.on('collect', r => {
msg.delete();

    message.channel.send(embed2)
})

adml.on('collect', r => {
msg.delete();

    message.channel.send(embed3)
})

divl.on('collect', r => {
msg.delete();

    message.channel.send(embed4)
})

infol.on('collect', r => {
msg.delete();

    message.channel.send(embed5)
})





      })
    })





}
