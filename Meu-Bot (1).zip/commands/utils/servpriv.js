const Discord = require("discord.js");
module.exports.run = async (client, message, args) =>{
message.delete().catch(O_o=>{});

if (!message.author.id === `723941793799864341`){
    return message.reply(
      "você é fraco, lhe falta permissão para usar esse comando"
    )}

if (message.author.id === `723941793799864341`) {    

let servidor = args[0]
if(!servidor) return message.reply("por favor, digite o ID do servidor!")
let guild = client.guilds.cache.find(gd => gd.id === servidor);
if(!guild)
return message.reply("por favor, digite um ID valido, o servidor não existe!")

const remover = new Discord.MessageEmbed()
.setAuthor("Remover bot!", client.user.avatarURL())
.setDescription(`Você realmente quer me tirar do servidor \`${guild.name}\` - \`${guild.id}\`?`)
.setTimestamp()
.setFooter(client.user.username, message.author.avatarURL)

message.channel.send(`:warning: **|** ${message.author}, você realmente quer me remover do servidor \`${guild.name}\` - \`${guild.id}\`?`).then(msg=> {
msg.react("✅🎵").then(r => {
msg.react("❎")

const sim = (reaction, user) => reaction.emoji.name === '✅' && user.id === message.author.id;
const nao = (reaction, user) => reaction.emoji.name === '❎' && user.id === message.author.id;
const siml = msg.createReactionCollector(sim, { time: 60000 });
const naol = msg.createReactionCollector(nao, { time: 60000 });
siml.on('collect', r => {
msg.delete();

message.channel.send(`:white_check_mark: **|** ${message.author}, sai do servidor \`${guild.name}\` (\`${guild.id}\`)!`)

client.channels.get("ID DO CANAL").send(`**Removido por ${message.author}!**`);
guild.leave()
})
naol.on('collect', r => {
msg.delete();

message.channel.send(`:negative_squared_cross_mark: **|** ${message.author}, você cancelou a minha remoção do servidor \`${guild.name}\` (\`${guild.id}\`)!`)
})
})
})
}
}