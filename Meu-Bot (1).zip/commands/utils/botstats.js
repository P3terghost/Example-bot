const Discord = require('discord.js');
const { version } = require("discord.js");
const moment = require("moment");
require("moment-duration-format");

exports.run = async (client, message, args) => {
message.delete();
const duration = moment.duration(client.uptime).format(" D [days], H [hrs], m [mins], s [secs]");

let avatar = message.author.displayAvatarURL({format: 'png'});
  const embed = new Discord.MessageEmbed()
        .setTitle('Informativo')
        .setColor('#7506ff')
        .addFields(
            { name: 'Memória:', value: `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB`, inline: true },
            { name: 'Uptime:', value: `${duration}`, inline: true },
        )
        .addFields(
            { name: 'Users:', value: `${client.users.cache.size.toLocaleString()}`, inline: true },
            { name: 'Servers:', value: `${client.guilds.cache.size.toLocaleString()}`, inline: true },
        )
        .addFields(
            { name: 'Channels:', value: `${client.channels.cache.size.toLocaleString()}`, inline: true },
            { name: 'Discord,js:', value: `v${version}`, inline: true },
        )
        .addFields(
            { name: 'Versão:', value: `1.0`, inline: true },
            { name: 'Meu criador:', value: `@Peterghost#0907`, inline: true },
            { name: 'Comandos:', value: `60`, inline: true },
        )
        .setImage('https://64.media.tumblr.com/a730d99062625d092faaac1efc558bf4/tumblr_ppki9k9suj1vgzd4so1_r1_500.gif')
        .setTimestamp()
        .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }))
        .setFooter(`Autor: ${message.author.username}`, message.author.avatarURL)
        .setAuthor(message.author.tag, avatar);
  await message.channel.send(embed);
};