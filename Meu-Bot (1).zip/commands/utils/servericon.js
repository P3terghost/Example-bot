const discord = require('discord.js')

module.exports = {
    name:"avatar",
    category:"info",
    run: async (client, message, args) => {
        
        const ft = message.guild.iconURL({format:'jpeg', size:1024})
        const avatar = message.guild.iconURL({ dynamic: true, size: 2048 })
        
        const embed = new discord.MessageEmbed()
        .setDescription(`**[Clique aqui](${ft}) **para baixar a foto`)
        .setAuthor(`${message.guild.name}`, avatar)
        .setImage(ft)
        .setFooter(`Comando Executado por ${message.author.tag}` , message.author.displayAvatarURL({ dynamic: true, size: 2048 }))
        
        message.channel.send(embed)
        
    }
}