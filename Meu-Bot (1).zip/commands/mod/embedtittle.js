const Discord = require("discord.js");

exports.run = async (client, message, args) => {
message.delete();
const content = args.join(" ");
if (!message.member.permissions.has("ADMINISTRATOR")){
  return message.reply(
    "você é fraco, lhe falta permissão para usar esse comando"
  )}

if (!args[0]) {
  return message.channel.send(`${message.author.username}, escreva uma mensagem após o comando`)
} else if (content.length > 1000) {
  return message.channel.send(`${message.author.username}, forneça uma mensagem de no máximo 1000 caracteres.`);
} else {

  const msg = await message.channel.send(
    new Discord.MessageEmbed()
    .setTitle(content)
    .setColor("#7506ff")
    .setFooter(" ")
    .setTimestamp()
  );
}
};