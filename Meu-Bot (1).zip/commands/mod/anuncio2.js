const Discord = require("discord.js");

exports.run = (client, message, args) => {

    message.channel.send(`**Qual o titulo?**`).then(msg3 => {
        let ck = message.channel.createMessageCollector(x => x.author.id == message.author.id, {max: 1})
        .on('collect', c => {
            title = c.content

    message.channel.send(`**Qual a mensagem desse anuncio?**`).then(msg2 => {
        let cl = message.channel.createMessageCollector(x => x.author.id == message.author.id, {max: 1})
        .on('collect', c => {
            desc = c.content

    let embed = new Discord.MessageEmbed()
    .setColor('#7506ff')
    .setThumbnail()
    .setTimestamp()
    .setTitle(title)
    .setDescription(`\`\`\`${desc}\`\`\``)

    message.channel.send(embed)

              })
            })
          })
        })
      }