const Discord = require('discord.js');

module.exports.run = async (client, message, args) => {
if (!args[0]) {
  return message.channel.send(
    new Discord.MessageEmbed()
    .setTitle("Say")
    .setColor("#7506ff")
    .setDescription("\n **Descrição: Voce fala por meio do BOT \n \n**Forma de Usa-lo: `say <Mensagem>`")
    .setFooter(" ")
    .setTimestamp())
}
  if (!message.member.permissions.has("BAN_MEMBERS")){
  return message.reply(
    "você é fraco, lhe falta permissão para usar esse comando"
    )}
  const sayMessage = args.join(' ');
  message.delete().catch(O_o => {});
  message.channel.send(sayMessage);
};