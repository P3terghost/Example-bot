const Discord = require("discord.js")

exports.run = async (client, message, args) => {
  
if (!message.member.hasPermission("BAN_MEMBER")) return message.reply('Você é fraco, lhe falta a permissão de `Banir usuarios` para usar esse comando.')

let user = message.mentions.users.first() || client.users.cache.get(args[0]);
if (!user) {
return message.reply('**lembre-se de mencionar um usuário para ser banido!**');}
if (user) {
        const member = message.guild.member(user);
  
      if (member) {
     
        member
          .ban({
            reason: '**Era besta!**',
          })
          .then(() => {
         
            message.reply(`**${user.tag} Banido com sucesso!**`);
          })
          .catch(err => {
         
            message.reply('**Não foi possivel banir este usuario**');
          
            console.error(err);
          });
      }
  }
}