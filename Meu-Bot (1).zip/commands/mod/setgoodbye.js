const Discord = require('discord.js')
const firebase = require('firebase')
const database = firebase.database()

module.exports.run = async(client, message, args) => {

if (!message.member.hasPermission("ADMINISTRATOR")) return message.reply('Você é fraco, lhe falta a permissão de `Administrador` para usar esse comando.')

let jackson = await database.ref(`Goodbye/${message.guild.id}`).once('value')

let canal = message.mentions.channels.first()

if(!canal) return message.channel.send('Mencione um canal válido!')

database.ref(`Goodbye/${message.guild.id}`).set({
canal: canal.id
});
message.channel.send(`Canal selecionado com sucesso!\nCanal: ${canal}`)
}