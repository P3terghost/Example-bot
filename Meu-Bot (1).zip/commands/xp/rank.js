const firebase = require('firebase');
const database = firebase.database();
const Discord = require('discord.js');
const meuSet = new Set();
module.exports.run = async(client, message, args) => {

const embederr = new Discord.MessageEmbed()
   .setDescription(`**${message.author.username}, não ha usuarios o suficiente para essa pagina!**`)
   .setColor('7506ff')
 
  const xp = await require('firebase').default.database().ref(`Servidores/Levels/${message.guild.id}`).once('value')

  if(xp.val() === null) return message.channel.send(embederr)

  let entries = Object.entries(xp.val());

  entries = entries.filter(([a, b]) => b["level"]);

  entries.sort((a, b) => b[1]["level"] - a[1]["level"]);

  if(args[0] === "local") {

    var filtro = entries.filter(([key, value], i) => (message.guild.members.cache.get(key)))

    var page = args[1]
    if(!page || isNaN(page) || page > 25) {
      page = 0
      num = 20
    } else {
      page = (args[1]-1)*5
      num = page+20
    }

    if(filtro.length < page+1) return message.channel.send(embederr)

    var x = filtro.map(([key, value], i) => "**"+ (i + 1) + "** - **" + (client.users.cache.get(key) ? client.users.cache.get(key).tag +"**" : "**Desconhecido#0000**")  + " - Level: **" + (value["level"] || 0) + "**\n").slice(page, num).join("")

    var rank = 'Ranking Do Servidor'
       
  } else {

    var rank = 'Ranking Do Servidor'

    var page = args[0]
    if(!page || isNaN(page) || page > 25) {
      page = 0
      num = 10
    } else {
      page = (args[0]-1)*5
      num = page+10
    }
 
    if(entries.length < page+1) return message.channel.send(embederr)
       
    var x = entries.map(([key, value], i) => "**"+ (i + 1) + "** - **" + (client.users.cache.get(key) ? client.users.cache.get(key).tag +"**" : "**Desconhecido#0000**") + " - Level: **" + (value["level"] || 0) + "**\n").slice(page, num).join("")
}

const embed2 = new Discord.MessageEmbed()
     .setAuthor(`🏆 ${rank}!`, message.author.avatarURL())
     .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }))
     .setColor('7506ff')
     .setDescription(`${x}\n`)
     message.channel.send(embed2);

}