const firebase = require('firebase');
const database = firebase.database();
const Discord = require('discord.js');
const meuSet = new Set();
module.exports.run = async(client, message, args) => {

    let amigo = message.mentions.users.first() || message.author;
    const db = await database.ref(`/Servidores/Levels/${message.guild.id}`).once('value');
    const array = Object.keys(db.val());
    
    array.forEach((e) => { 
        let infoMembro = {
            id: `${e}`, level: db.val()[e].level, xp: db.val()[e].xp
        };
        meuSet.add(infoMembro)
    });

     let pe = Array.from(meuSet);
     let xy = pe.sort(function (a, b) {
         if (a.xp < b.xp) {
           return 1;
         }
         if (a.xp > b.xp) {
           return -1;
         }
         return 0;
     });

     let suaPosicao;
     xy.forEach(async function (membro, indice){
         if (membro.id == message.author.id) {
             suaPosicao = `🏆 Posição: **#${indice+1}**`
         }
     })
     let x = [];

     if (xy.length >= 10) {
         for (y = 0; y < 10; y++) {
             let level = xy.slice(y, y+1).map(a => a.level);
             let id = String(xy.slice(y, y+1).map(a => a.id));
 
             x += `**${y+1}** - **${client.users.cache.get(id).tag}** - Level: **${level}**\n`
         }
     } else {
         for (y = 0; y < xy.length; y++) {
             let xp = xy.slice(y, y+1).map(a => a.xp);
             let level = xy.slice(y, y+1).map(a => a.level);
             let id = xy.slice(y, y+1).map(a => a.id);
 
             x += `**#${y+1}** - **<@${String(id)}>** - Level: **${level}** / **${xp}**xp\n`
         }
     }
 const embed = new Discord.MessageEmbed()
     .setAuthor(`🏆 Top Rank do Servidor!`, message.author.avatarURL())
     .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 1024 }))
     .setColor('7506ff')
     .setDescription(`${x}\n${suaPosicao}`)
     message.channel.send(embed);
 
     meuSet.clear();
}