module.exports = (client, message, track) => {

    message.channel.send(`${client.emotes.music} **| tocando agora** ${track.title} **no** ${message.member.voice.channel.name} ...`);

};