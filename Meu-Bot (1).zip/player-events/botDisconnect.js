module.exports = (client, message, queue) => {

    message.channel.send(`${client.emotes.error} **| A música parou porque fui desconectada do canal!**`);
            console.log("p3terghost#0907")
};
