module.exports = (client, message, playlist) => {

    message.channel.send(`${client.emotes.music} - ${playlist.title} **foi adicionado à fila** (**${playlist.items.length}** songs) !`);
            console.log("p3terghost#0907")
};