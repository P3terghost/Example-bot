module.exports = (client, message, query) => {

    message.channel.send(`${client.emotes.error} **| Nenhum resultado encontrado para** ${query} **!**`);
            console.log("p3terghost#0907")
};