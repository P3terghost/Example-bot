module.exports = (client, message, queue) => {

    message.channel.send(`${client.emotes.error} **| A música parou porque acabou a fila!**`);
            console.log("p3terghost#0907")
};