module.exports = (client, message, queue) => {

    message.channel.send(`${client.emotes.error} **| A música parou porque não há mais membros no canal de voz!**`);
            console.log("p3terghost#0907")
};