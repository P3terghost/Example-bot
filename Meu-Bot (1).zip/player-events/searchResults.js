module.exports = (client, message, query, tracks) => {

    message.channel.send({
        embed: {
            color: '#7506ff',
            author: { name: `Aqui estão os resultados da sua pesquisa para ${query}` },
            footer: { text: 'p3terghost#0907' },
            timestamp: new Date(),
            description: `${tracks.map((t, i) => `**${i + 1}** - ${t.title}`).join('\n')}`,
        },
    });
            console.log("search Ready")
};